-- 简历初筛主表
CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_session_id TEXT NOT NULL,
    scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    platform TEXT NOT NULL,            -- 平台: liepin / boss / etc.
    candidate_name TEXT,
    current_position TEXT,
    current_company TEXT,
    expected_city TEXT,
    applied_position TEXT,             -- 应聘岗位（对应 JD 序号/岗位名）
    jd_key TEXT,                       -- 命中的 JD key
    verdict TEXT NOT NULL,             -- 合适 / 待定 / 不合适 / 信息不足
    score REAL,                        -- 0-100 综合分
    reason TEXT,                       -- 判定理由（短摘要）
    hits TEXT,                         -- JSON: 命中的条件列表
    misses TEXT,                       -- JSON: 缺失/不达标的条件列表
    detail_json TEXT,                  -- 原始解析结果 JSON
    page_url TEXT,                     -- 候选人详情页 URL
    operated INTEGER DEFAULT 0,        -- 是否已在猎聘网页面上执行了通过/不合适操作
    operated_at TIMESTAMP,
    note TEXT
);

CREATE INDEX IF NOT EXISTS idx_session ON candidates(scan_session_id);
CREATE INDEX IF NOT EXISTS idx_verdict ON candidates(verdict);
CREATE INDEX IF NOT EXISTS idx_scanned_at ON candidates(scanned_at);

-- 扫描会话
CREATE TABLE IF NOT EXISTS scan_sessions (
    id TEXT PRIMARY KEY,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    finished_at TIMESTAMP,
    platform TEXT,
    scanned_count INTEGER DEFAULT 0,
    qualified INTEGER DEFAULT 0,
    pending INTEGER DEFAULT 0,
    rejected INTEGER DEFAULT 0,
    incomplete INTEGER DEFAULT 0,
    status TEXT DEFAULT 'running'      -- running / done / error
);
